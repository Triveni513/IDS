# Intrusion-Detection-System
Intrusion Detection System (IDS) with Flask GUI – IDS with Flask GUI: Securely monitor, analyze network threats. Real-time alerts, customizable rules, and an intuitive web interface for efficient security management which detects any network anamoly.
