import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
import xgboost as xgb
from sklearn.ensemble import RandomForestClassifier

# Load the dataset
print("Loading dataset...")
data = pd.read_csv('System\KDDTrain.csv')
print("Dataset loaded successfully.")

# Remove single quotes from column names
data.columns = data.columns.str.strip("'")

# Encode categorical variables
le = LabelEncoder()
data['protocol_type'] = le.fit_transform(data['protocol_type'])
data['flag'] = le.fit_transform(data['flag'])
data['class'] = le.fit_transform(data['class'])

# Separate features and labels
X = data.drop('class', axis=1)
y = data['class']

# Scale the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Create a Random Forest model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_scaled, y)

# Create an XGBoost model
xgb_model = xgb.XGBClassifier(objective="binary:logistic", random_state=42)
xgb_model.fit(X_scaled, y)

def preprocess_input(user_input):
    user_input_df = pd.DataFrame([user_input])

    features_used = ['protocol_type', 'flag', 'src_bytes', 'dst_bytes', 'hot','count', 'srv_count',
                     'same_srv_rate', 'dst_host_count', 'dst_host_srv_count',
                     'dst_host_same_srv_rate', 'dst_host_diff_srv_rate',
                     'dst_host_same_src_port_rate', 'dst_host_rerror_rate']

    # Keep only the features used during training
    user_input_df = user_input_df[features_used]

    # Transform categorical features using the same label encoder used during training
    for column in ['protocol_type', 'flag']:
        if column in le.classes_:
            user_input_df[column] = le.transform(user_input_df[column])
        else:
            # Handle unseen labels by assigning a default value or using a specific strategy
            user_input_df[column] = -1  # Replace with a suitable default value or strategy

    return user_input_df

def predict_user_input(user_input):
    preprocessed_input = preprocess_input(user_input)
    
    # Predict with Random Forest model
    rf_prediction = rf_model.predict(preprocessed_input)
    
    # Predict with XGBoost model
    xgb_prediction = xgb_model.predict(preprocessed_input)
    
    # Combine predictions (for simplicity, taking the mode)
    hybrid_prediction = max(rf_prediction[0], xgb_prediction[0])  # Change based on your logic
    
    print("Hybrid predicted class label:", hybrid_prediction)
    return rf_prediction[0], xgb_prediction[0], hybrid_prediction

def predict_dataset(data):
    rf_preds = []
    xgb_preds = []
    hybrid_preds = []
    actual_labels = data['class']

    for index, row in data.iterrows():
        preprocessed_input = preprocess_input(row)
        
        # Convert preprocessed_input to numpy array
        preprocessed_input_np = preprocessed_input.values.reshape(1, -1)
        
        # Predict with Random Forest model
        rf_prediction = rf_model.predict(preprocessed_input_np)
        
        # Predict with XGBoost model
        xgb_prediction = xgb_model.predict(preprocessed_input_np)
        
        # Combine predictions (for simplicity, taking the mode)
        hybrid_prediction = max(rf_prediction[0], xgb_prediction[0])  # Change based on your logic
        
        rf_preds.append(rf_prediction[0])
        xgb_preds.append(xgb_prediction[0])
        hybrid_preds.append(hybrid_prediction)
    
    return actual_labels, rf_preds, xgb_preds, hybrid_preds


# Predict labels for the entire dataset
actual_labels, rf_preds, xgb_preds, hybrid_preds = predict_dataset(data)

# Plotting
labels = ['Normal', 'Anomaly']
x = np.arange(len(actual_labels))

plt.figure(figsize=(14, 8))
plt.plot(x, actual_labels, 'bo', label='Actual Labels', markersize=5)
plt.plot(x, rf_preds, 'r^', label='RF Predictions', markersize=5)
plt.plot(x, xgb_preds, 'gs', label='XGBoost Predictions', markersize=5)
plt.plot(x, hybrid_preds, 'm*', label='Hybrid Predictions', markersize=5)
plt.xlabel('Data Point Index')
plt.ylabel('Label')
plt.title('Comparison of Actual and Predicted Labels')
plt.xticks(rotation=45)
plt.yticks([0, 1], labels)
plt.legend()
plt.tight_layout()
plt.show()
