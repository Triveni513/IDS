import pandas as pd
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
import xgboost as xgb

print("Loading dataset...")
data = pd.read_csv('System\KDDTrain.csv')
print("Dataset loaded successfully.")

# Remove single quotes from column names
data.columns = data.columns.str.strip("'")

# Encode categorical variables
le = LabelEncoder()
data['protocol_type'] = le.fit_transform(data['protocol_type'])
data['flag'] = le.fit_transform(data['flag'])
data['class'] = le.fit_transform(data['class'])

# Separate features and labels
X = data.drop('class', axis=1)
y = data['class']

# Scale the data
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print("Training Random Forest model...")
# Create a Random Forest model
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)

# Train the Random Forest model
rf_model.fit(X_scaled, y)
print("Random Forest model trained successfully.")

print("Training XGBoost model...")
# Create an XGBoost model
xgb_model = xgb.XGBClassifier(objective="binary:logistic", random_state=42)

# Train the XGBoost model
xgb_model.fit(X_scaled, y)
print("XGBoost model trained successfully.")

def preprocess_input(user_input):
    user_input_df = pd.DataFrame([user_input])

    features_used = ['protocol_type', 'flag', 'src_bytes', 'dst_bytes', 'hot','count', 'srv_count',
                     'same_srv_rate', 'dst_host_count', 'dst_host_srv_count',
                     'dst_host_same_srv_rate', 'dst_host_diff_srv_rate',
                     'dst_host_same_src_port_rate', 'dst_host_rerror_rate']

    # Keep only the features used during training
    user_input_df = user_input_df[features_used]

    # Transform categorical features using the same label encoder used during training
    for column in ['protocol_type', 'flag']:
        if column in le.classes_:
            user_input_df[column] = le.transform(user_input_df[column])
        else:
            # Handle unseen labels by assigning a default value or using a specific strategy
            user_input_df[column] = -1  # Replace with a suitable default value or strategy

    return user_input_df

def predict_user_input(user_input):
    preprocessed_input = preprocess_input(user_input)
    
    # Predict with Random Forest model
    rf_prediction = rf_model.predict(preprocessed_input)
    
    # Predict with XGBoost model
    xgb_prediction = xgb_model.predict(preprocessed_input)
    
    # Combine predictions (for simplicity, taking the mode)
    hybrid_prediction = max(rf_prediction[0], xgb_prediction[0])  # Change based on your logic
    
    print("Hybrid predicted class label:", hybrid_prediction)
    return hybrid_prediction
